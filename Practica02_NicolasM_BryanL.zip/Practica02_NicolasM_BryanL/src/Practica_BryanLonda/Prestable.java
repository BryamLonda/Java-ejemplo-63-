package Practica_BryanLonda;

public interface Prestable {
	interface prestable {
	    void prestar();
	    void devolver();
	    boolean estaPrestado();
	}

	void prestar();

	void devolver();

	boolean estaPrestado();


}